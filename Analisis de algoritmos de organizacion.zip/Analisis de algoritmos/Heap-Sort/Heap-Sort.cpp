#include<stdio.h>//Funciones de entrada y salida estandar
#include<conio.h>
#include <windows.h>//Para usar cls  
#include <iostream>
  using namespace std;
  
void heapify(int arraysort[], int n, int i);//Definicion de funciones prototipo
void heapSort(int arraysort[], int n);
void ImprimirArray(int arraysort[], int n);
void swap(int *a, int *b);  


  int main() {
  			printf("-------173389, Mendoza Monreal Jose Israel,Heap-Sort Analisis Algoritmos , 30-06-2021, Verano 2021--------\n");//Datos de Alumno
	for(int i=0;i<102;i++){
		printf("_");
	}//Separador
	printf("\n");//Espaciador
	
	int n;//Variable para tama�o
	printf("Ingrese el numero de elementos: ");
	scanf("%d",&n);//Guarda la entrada de tama�o
	fflush(stdin);//Limpieza de buffer
	int arraysort[n];//Define el tama�o de el array
	for(int i = 0; i < n; i++){//Este ciclo for pide y almacena los n valores que se ingresen
		printf("Ingrese el elemento %d\n",(i+1));
		scanf("%d",&arraysort[i]);//Guarda el valor dentro del espacio del arraysort
		fflush(stdin);//Limpieza de buffer
	}	
    //int arraysort[] = {1, 12, 9, 5, 6, 10};
    //int n = sizeof(arraysort) / sizeof(arraysort[0]);
    //printf("%d",n);
	printf("Array Desordenado:\n");//Imprime el array desordenado
    ImprimirArray(arraysort, n);//Llamada de funcion a imprimirarray
    printf("\n");//Espaciador
	heapSort(arraysort, n);//Se llama a la funcion heapSort
  
    printf("\nArray Ordenado:\n");//Imprime el array ordenado
    ImprimirArray(arraysort, n);//Llamada de funcion a imprimirarray
	getch();//Espera el apretado de una tecla para seguir
	return 0;
  }
  
void swap(int *a, int *b) {//Esta funcion cambia 2 valores pasados sus ubicaciones de memoria
    int aux = *a;
    *a = *b;
    *b = aux;
}

  void heapify(int arraysort[], int n, int i) {//Esta funcion realiza los cambios y organiza los datos de forma de MAX-HEAP
    // Encuentra el mas largo entre la raiz de el hijo izquierdo y el hijo derecho
    int ubermayor = i;//El mayor dato se iguala a i
    int L = 2 * i + 1;//Se establece el pivote de la izquierda
    int R = 2 * i + 2;//Se establece el povote de la derecha
  
    if (L < n && arraysort[L] > arraysort[ubermayor])//Este if determina si el numero mayor corresponde al hijo izquierdo
      ubermayor = L;
  
    if (R < n && arraysort[R] > arraysort[ubermayor])//Este if determina si el numero mayor corresponde al hijo derecha
      ubermayor = R;
  

    if (ubermayor != i) {    // Este if cambia y continua el heapifying si la raiz no es igual la variable ubermayor 
      swap(arraysort[i], arraysort[ubermayor]);//Llamada de funcion de cambio
      heapify(arraysort, n, ubermayor);//Llamada de funcion heapify
    }
  }
  
  
  void heapSort(int arraysort[], int n) {// Esta funcion realiza el heap sort
    // Se crea el MAX-HEAP
    for (int i = n / 2 - 1; i >= 0; i--)//Este for realiza el heapify por la cantidad de datos/2-1
      heapify(arraysort, n, i);//Llamada de funcion heapify
  
    // Este for realiza el heap sort realizando los cambios y heapify necesarios para determinar donde debe ir cada valor
    for (int i = n - 1; i >= 0; i--) {
      swap(arraysort[0], arraysort[i]);
  
      // Heapify el elemento de la raiz para obtener el mayor elemento como raiz de nuevo
      heapify(arraysort, i, 0);
    }
  }
  

  void ImprimirArray(int arraysort[], int n) {  // Esta funcion realiza la impresion del array
    for (int i = 0; i < n; ++i)
      printf("%d\n",arraysort[i]);
  }
  
