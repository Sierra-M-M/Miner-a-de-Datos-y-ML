#include<stdio.h>//Funciones de entrada y salida estandar
#include<conio.h>
#include <windows.h>//Para usar cls

void imprimir(int *arraysort,int n);//Definicion de funciones prototipo
void intercambio(int &a, int &b);
void mezcla(int *arraysort, int l, int m, int r);
void mezclaSort(int *arraysort,  int l, int r);

int main(){
		printf("-------173389, Mendoza Monreal Jose Israel,Merge-Sort Analisis Algoritmos , 23-06-2021, Verano 2021--------\n");//Datos de Alumno
	for(int i=0;i<102;i++){
		printf("_");
	}//Separador
	printf("\n");//Espaciador
	int n;//Variable para tama�o
	printf("Ingrese el numero de elementos: ");
	scanf("%d",&n);//Guarda la entrada de tama�o
	fflush(stdin);//Limpieza de buffer
	int array[n];//Define el tama�o de el array
	for(int i = 0; i < n; i++){//Este ciclo for pide y almacena los n valores que se ingresen
		printf("Ingrese el elemento %d\n",(i+1));
		scanf("%d",&array[i]);//Guarda el valor dentro del espacio del array
		fflush(stdin);//Limpieza de buffer
	}
	printf("Array antes de ordenar\n");
	imprimir(array,n);//Llamada de funcion imprimir, se le envia los apuntadores de array y el valor de n
	mezclaSort(array,0,n-1);//llamada de funcion recursiva mezclaSort que empieza a ordenar el array
	printf("Array despues de ordenar\n");
	imprimir(array,n);//Llamada de funcion imprimir, se le envia los apuntadores de array y el valor de n
	getch();//Espera el apretado de una tecla para seguir
	return 0;
}

void imprimir(int *arraysort, int n){
	for(int i = 0; i < n; i++)//Este ciclo for imprime el array completo
	printf("%d - ",arraysort[i]);//Imprime el array por posicion
	printf("\n");//Separador
}

void intercambio(int &a, int &b){
	int aux;//Se crea variable auxiliar
	aux = a;//Se iguala el valor de la variable auxiliar al dato a
	a = b;//Se iguala el valor del dato a al del dato b
	b = aux;//Se iguala el valor del dato b al valor de la variable auxiliar
}

void mezcla(int *arraysort, int l, int m, int r){
int i, j, k, nl, nr;//Se definen las variables contadores i y j, se establece la key como k, y se establece la extension de el array izquierdo como nl y el derecho como nr
   nl = m-l+1;//Se le asigna el valor de la extension del array izquierdo con los datos de m,l y sumando 1
   nr = r-m;//Se le asigna el valor de la extension del array derecho con los datos de m, y r
   int larr[nl], rarr[nr];//Se crean los arrays con dicha respectiva extension
   for(i = 0; i<nl; i++){//Este ciclo for llena el array de la izquierda con los valores del array original
      larr[i] = arraysort[l+i];
	  }
   for(j = 0; j<nr; j++){//Este ciclo for llena el array de la derecha con los valores del array original
      rarr[j] = arraysort[m+1+j]; 
	  }
   i = 0; j = 0; k = l;//Se reinician los contadores y se le da el valor de la key como la posicion de la izquierda
   //marge temp arrays to real array
   while(i < nl && j<nr) {//Este ciclo while asigna el valor menor o igual del array izquierdo o derecho por medio de un if y lo ingresa en el array original en su lugar correspondiente
      if(larr[i] <= rarr[j]) {//If para el array de la izquierda
         arraysort[k] = larr[i];
         i++;//suma 1 al valor de i
      }else{//else if del array de la derecha
         arraysort[k] = rarr[j];
         j++;//suma 1 al valor de j
      }
      k++;//suma 1 al valor de k
   }
   while(i<nl) {//Este ciclo while representa el elemento extra del array izquierdo
      arraysort[k] = larr[i];
      i++; k++;//suma 1 al valor de k y de i
   }
   while(j<nr) {//Este ciclo while representa el elemento extra del array derecho
      arraysort[k] = rarr[j];
      j++; k++;//suma 1 al valor de k y j
   }
}

void mezclaSort(int *arraysort, int l, int r){
	int m;//Se define la variable de m
	   if(l < r) {//Este if determinara la continuidad del algoritmo merge-sort
	      int m = l+(r-l)/2;//Se define el valor de la variable de m con el valor la longitud izquierda mas el valor de la izquierda reducida en 1, todo divido entre 2
	      // Estas llamadas a funcion organizan los arrays de la izquierda y derecha respectivamente
	      mezclaSort(arraysort, l, m);
	      mezclaSort(arraysort, m+1, r);
	      mezcla(arraysort, l, m, r);//Al final, junta los 2 arrays en el original
   }
}
