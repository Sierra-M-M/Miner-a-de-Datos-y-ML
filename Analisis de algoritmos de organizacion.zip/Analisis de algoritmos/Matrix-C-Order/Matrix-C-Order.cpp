#include<iostream>
#include<stdio.h>//Funciones de entrada y salida estandar
#include<conio.h>
#include <windows.h>//Para usar cls 
#include<limits.h>
 

//Definicion de funciones prototipo
 int MCO(int p[], int n);
 
int MCO(int p[], int n){

    int m[n][n];//Se definen arrays cuadrados
    int i, j, k, L, q;//Se definen variables auxiliares para contadores, longitudes y datos multiplicados
 
    for (i=1; i<n; i++)//Este for repetira el codigo por cada dimension+1
        m[i][i] = 0;    //Las bases de las multiplicaciones son 0 y se definen como cimientos de la matriz
 
    //L es la longitud de la cadena, varia de longitud 2 a longitud n.
    for (L=2; L<n; L++)//Este for se ejecutara en base a la longitud hasta <n
    {
        for (i=1; i<n-L+1; i++)//Este for anidado reproducira las multiplicaciones
        {
            j = i+L-1;//Se establece j con el valor de la iteracion+L-1
            m[i][j] = INT_MAX;  //Se assigna al valor maximo
 
            for (k=i; k<=j-1; k++)//Este for anidado reproducira las multiplicaciones
            {
                q = m[i][k] + m[k+1][j] + p[i-1]*p[k]*p[j];//Se multiplican los valores de las dimensiones
                if (q < m[i][j])//Si el valor de q es menor al la ubicacion actual
                {
                    m[i][j] = q;    //Si el numero de multiplicaciones es menor que el encotrado se escribira en la matriz
                }
            }
        }
    }
 
    return m[1][n-1];   //se hace return con el valor del valor minimo encontrado
 
}
 
int main(){
	  			printf("-------173389, Mendoza Monreal Jose Israel,Matrix-Chain-Order Analisis Algoritmos , 08-07-2021, Verano 2021--------\n");//Datos de Alumno
	for(int i=0;i<102;i++){
		printf("_");
	}//Separador
	printf("\n");//Espaciador	
    int n,i;//Se establecen variables primarias para el numero de matrices y un contador
    printf("Enter number of matrices\n");
    scanf("%d",&n);//Se captura la variable n
	fflush(stdin);//Limpieza de buffer
    n++;
 
    int array[n];//Se define el array principal en base a n
 
    printf("Ingrese las dimensiones \n");
 
    for(i=0;i<n;i++)
    {
        printf("Ingrese la dimension %d : ",i);
        scanf("%d",&array[i]);
        fflush(stdin);//Limpieza de buffer
    }
 
    int tamanio = sizeof(array)/sizeof(array[0]);//Se crea una variable para allocar el tama�o de los datos del array
 
    printf("El numero minimo de multiplicaciones es %d ", MCO(array, tamanio));
 	getch();//Espera el apretado de una tecla para seguir
    return 0;
}
