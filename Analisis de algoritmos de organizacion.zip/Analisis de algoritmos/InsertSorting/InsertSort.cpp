#include<stdio.h>//Funciones de entrada y salida estandar
#include<conio.h>
#include <windows.h>//Para usar cls

void imprimir(int *arraysort,int n);//Definicion de funciones prototipo
void InsertSort(int *arraysort,int n);

int main(){
		printf("-------173389, Mendoza Monreal Jose Israel,Insert Sort Analisis Algoritmos , 22-06-2021, Verano 2021--------\n");//Datos de Alumno
	for(int i=0;i<102;i++){
		printf("_");
	}//Separador
	printf("\n");//Espaciador
	int n;//Variable para tama�o
	printf("Ingrese el numero de elementos: ");
	scanf("%d",&n);//Guarda la entrada de tama�o
	fflush(stdin);//Limpieza de buffer
	int array[n];//Define el tama�o de el array
	for(int i = 0; i < n; i++){//Este ciclo for pide y almacena los n valores que se ingresen
		printf("Ingrese el elemento %d\n",(i+1));
		scanf("%d",&array[i]);//Guarda el valor dentro del espacio del array
		fflush(stdin);//Limpieza de buffer
	}
	printf("Array antes de ordenar\n");
	imprimir(array,n);//Llamada de funcion imprimir, se le envia los apuntadores de array y el valor de n
	InsertSort(array,n);//Llamada de funcion de Insert-Sort, se le envia los apuntadores de array y el valor de n
	printf("Array despues de ordenar\n");
	imprimir(array,n);//Llamada de funcion imprimir, se le envia los apuntadores de array y el valor de n
	getch();//Espera el apretado de una tecla para seguir
	return 0;
}

void imprimir(int *arraysort, int n){
	for(int i = 0; i < n; i++)//Este ciclo for imprime el array completo
	printf("%d - ",arraysort[i]);//Imprime el array por posicion
	printf("\n");//Separador
}

void InsertSort(int *arraysort, int n){
   int key, j;//Se definen las variables de llave y j
   
   for(int i = 1; i<n; i++) {//Este ciclo for se utiliza para ordernar el array, y se repite en cada espacio del array
      key = arraysort[i];//Toma el valor de la posicion del array para key
      j = i;//Se iguala el valor de j al de i;
      
      while(j > 0 && arraysort[j-1]>key) {//Este ciclo while se ejecutara mientras j > 0 y la posicion anterior de arraysort sea mayor a la key
         arraysort[j] = arraysort[j-1];//Se iguala el valor de arraysort de la posicion actual al de la posicion arraysort anterior 
         j--;//Se le resta 1 al valor de j
      }
      arraysort[j] = key;   //Lo inserta en la posicion correspondiente
}
}
