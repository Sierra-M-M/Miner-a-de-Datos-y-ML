#include<iostream>
#include<stdio.h>//Funciones de entrada y salida estandar
#include<conio.h>
#include <windows.h>//Para usar cls 

using namespace std;

struct nodo//Se crea una estructura de nodos
{//Se definen variables
       int llave;//se define el dato
       nodo *padre;//Se define el apuntador de padre
       char color;//Se define el color por char
       nodo *izq;//Se define el apuntador a izq
       nodo *der;//Se define el apuntador a der
};
class RBtree//Se crea una clase con nombre RBTree
{
      nodo *raiz;//Se define el apuntador de la raiz
      nodo *q;//Se define el apuntador de q
   public :
      RBtree(){
              q=NULL;//Se apunta q a NULL
              raiz=NULL;//Se apunta raiz a NULL
      }
      //Se definen las funciones prototipo
      void insert();
      void insertfix(nodo *);
      void leftrotate(nodo *);
      void rightrotate(nodo *);
      void del();
      nodo* successor(nodo *);
      void delfix(nodo *);
      void disp();
      void display( nodo *);
      void search();
};
void RBtree::insert()//Esta funcion ingresa nodos al arbolRB
{
     int z,i=0;//Se definen variables auxiliares
     printf("\nIngrese la llave a insertar: ");
     scanf("%d",&z);//Se captura el valor de z
     fflush(stdin);//Limpieza de buffer
     nodo *p,*q;//Se definen los apuntadores p y q
     nodo *t=new nodo;//Se define el apuntador de t como el nuevo nodo
     t->llave=z;//Se asigna el valor de la llave al de z
     t->izq=NULL;//Se asigna el valor del apuntador izq a NULL
     t->der=NULL;//Se asigna el valor del apuntador der a NULL
     t->color='r';//Se asigna el valor del color a r
     p=raiz;//Se asigna a p al valor de raiz
     q=NULL;//Se asigna a q a NULL
     if(raiz==NULL)//Este if revisa si la raiz es igual a NULL
     {
           raiz=t;//Se iguala la raiz a t
           t->padre=NULL;//se asinga como padre NULL
     }
     else//De lo contrario
     {
         while(p!=NULL)//Mientras que p sea diferente de NULL
         {
              q=p;//q se iguala a p
              if(p->llave<t->llave)//Este if revisa si la llave de p es menor a la llave de t
                  p=p->der;//Se establece a p como der de p
              else//De lo contrario
                  p=p->izq;//Se establece a p como izq de p
         }
         t->padre=q;//Se asigna el padre de t al valor de q
         if(q->llave<t->llave)//Este if revisa si la llave de q es menor a la llave de t
              q->der=t;//Se establece a q como der de t
         else//De lo contrario
              q->izq=t;//Se establece a q como izq de t
     }
     insertfix(t);//Se llama la la funcion insertfix con valor t
}
void RBtree::insertfix(nodo *t)//Esta funcion inserta nodos y acomoda los datos en caso que exista desequilibrio
{
     nodo *u;//Se establece un apuntador a u
     if(raiz==t)//Este if revisa si la raiz es igual a t
     {
         t->color='b';//Se establece el color de t a negro
         return;//Se hace return
     }
     while(t->padre!=NULL&&t->padre->color=='r')//Mientras el padre de t sea diferente de NULL y el color del padre de t sea rojo se ejecutara esa seccion del codigo
     {
           nodo *g=t->padre->padre;//Se establece un apuntador a g con valor del padre del padre de t
           if(g->izq==t->padre)//Si el hijo izquierdo de g es igual al padre de t se ejecutara este if
           {
                        if(g->der!=NULL)//Si el hijo derecho de g es diferente de null se ejecutara este if
                        {
                              u=g->der;//Se define a u con el valor del hijo derecho de g
                              if(u->color=='r')//Si u es de color rojo se ejecutara este if
                              {
                                   t->padre->color='b';//El padre de t se hace color negro
                                   u->color='b';//El color de u se establece a negro
                                   g->color='r';//El color de h se establece a rojo
                                   t=g;//T sea iguala a g
                              }
                        }
                        else//De lo contrario
                        {
                            if(t->padre->der==t)//Si el hijo derecho del padre de t es igual a t
                            {
                                 t=t->padre;//Se define t a el valor del padre de t
                                 leftrotate(t);//Se rota a la izquierda en base a t
                            }
                            t->padre->color='b';//El color del padre de t se establece a negro
                            g->color='r';//El color de g se establece a rojo
                            rightrotate(g);//Se rota a la derecha en base a g
                        }
           }
           else//De lo contrario
           {
                        if(g->izq!=NULL)//Si el hijo de la izquerda es diferente de NULL
                        {
                             u=g->izq;//Se establece a u al valor del hijo izq de g
                             if(u->color=='r')//Si el color de u es igual a rojo 
                             {
                                  t->padre->color='b';//Se establece el color del padre de t a negro
                                  u->color='b';// Se establece el color de u a negro
                                  g->color='r';// Se establece el color de g a rojo
                                  t=g;// Se establece a t al valor de g
                             }
                        }
                        else//De lo contario
                        {
                            if(t->padre->izq==t)//Si el hijo izq del padre de t es igual a t
                            {
                                   t=t->padre;//Se establece el valor de t al padre de t
                                   rightrotate(t);// Se rota a la derecha en base a t
                            }
                            t->padre->color='b';// Se establece el color del padre de t a negro
                            g->color='r';// Se establece el color de g a rojo
                            leftrotate(g);// Se rota a la izq en base a g
                        }
           }
           raiz->color='b';//Se define el color de la raiz a negro
     }
}

void RBtree::del()
{
     if(raiz==NULL)//Si la raiz es igual a null
     {
           printf("\nArbol vacio.");
           return ;//Se hace return
     }
     int x;//Se define una variable auxiliar
     printf("\nIngrese la llave a eliminar: ");
     scanf("%d",&x);//Se captura el valor de x
     fflush(stdin);//Limpieza de buffer
     nodo *p;//Se establece un apuntador p
     p=raiz;//Se establece el valor de p al de la raiz
     nodo *y=NULL;//Se establece un apuntador y con valor NULL
     nodo *q=NULL;//Se establece un apuntador q con valor NULL
     int found=0;//Se establece una variable auxiliar con valor 0
     while(p!=NULL&&found==0)//Mientras el apuntador sea diferente de null y found igual a 0 se ejecutara este bloque de codigo
     {
           if(p->llave==x)//Si la llave de p es igual a x
               found=1;//Se establece found a 1
           if(found==0)//Si found es igual a 0
           {
                 if(p->llave<x)//Y si la llave de p es igual a x
                    p=p->der;//Se establece p al valor del hijo derecho de p
                 else//De lo contrario
                    p=p->izq;//Se establece p al valor del hijo izq de p
           }
     }
     if(found==0)//Si found es igual a 0
     {
            printf("\nElemento no encontrado.");
            return ;//Se hace return
     }
     else//De lo contrario
     {
         printf("\nElemento eliminado: %d",p->llave);
         printf("\nColor: ");
         if(p->color=='b')//Si el color de p es igual a b se imprimira
     printf("Negro\n");
    else//De lo contrario
     printf("Rojo\n");

         if(p->padre!=NULL)//Si el padre de p es diferente de null
               printf("\n Padre: %d",p->padre->llave);
         else//De lo contrario
               printf("\n No hay padre del nodo");
         if(p->der!=NULL)//Si el hijo derecho de p es diferente de null
               printf("\nHijo derecho: %d",p->der->llave);
         else//De lo contrario
               printf("\n TNo hay hijo derecho del nodo");
         if(p->izq!=NULL)//Si el hijo izq de p es diferente de null
               printf("\n Hijo izquierdo: %d",p->izq->llave);
         else//De lo contrario
               printf("\n TNo hay hijo izquierdo del nodo");
         printf("\nNodo Eliminado.");
         if(p->izq==NULL||p->der==NULL)//Si el hijo izq de p es igual a null o el hijo derecho de p es igual a null
              y=p;//Se establece el valor de y al de p
         else//De lo contrario
              y=successor(p);//Se establece el valor de y al sucessor de p
         if(y->izq!=NULL)//Si el valor del hijo izq es diferente de null
              q=y->izq;//Se establece el valor de q al hijo izq de y
         else//De lo contrario
         {
              if(y->der!=NULL)//Si el valor del hijo der de y es diferente de NULL
                   q=y->der;//Se establece el valor de q al hijo derecho de y
              else//De lo cotrario
                   q=NULL;//Se establece q como null
         }
         if(q!=NULL)//Si q es diferente de null
              q->padre=y->padre;//Se establece el padre de q al valor del padre de y
         if(y->padre==NULL)//SI el padre de y es igual a null
              raiz=q;//Se establece la raiz al valor de q
         else//De lo contrario
         {
             if(y==y->padre->izq)//Si el valor de y es igual al hijo izq del padre de y 
                y->padre->izq=q;//El hijo izq del padre de y se establece al valor de q
             else//De lo contrario
                y->padre->der=q;//El hijo derecho del padre de y se establece al valor de q
         }
         if(y!=p)//Si el valor de y es diferente al de p
         {
             p->color=y->color;//Se establece el color de p al color de y
             p->llave=y->llave;//Se establece la llave de p a la llave de y
         }
         if(y->color=='b')//Si el color de y es igual a negro
             delfix(q);//Se elimina y arregla el arbol en torno al valor de q
     }
}

void RBtree::delfix(nodo *p)//Esta funcion realiza la eliminacion de un nodo y realiza el balance/ acomodo conforme al valor eliminado
{
    nodo *s;//Se define un apuntador s
    while(p!=raiz&&p->color=='b')//Mientras p sea diferente de la raiz y el color de p sea igual a negro
    {
          if(p->padre->izq==p)//Si el hijo izq del padre de p es igual a p
          {
                  s=p->padre->der;//Se establece el valor de s a el hijo der del padre de p
                  if(s->color=='r')//Si el color de s es igual a rojo
                  {
                         s->color='b';//Se establece el color de s a negro
                         p->padre->color='r';//Se establece el color del padre de p a rojo
                         leftrotate(p->padre);//Se realiza rotacion izq en base al padre de p
                         s=p->padre->der;//Se establece el valor de s al valor del hijo der del padre de p
                  }
                  if(s->der->color=='b'&&s->izq->color=='b')//Si el hijo der de s es negro y el hijo izq de s es negro
                  {
                         s->color='r';//Se establece el color de s a rojo
                         p=p->padre;//Se establece el valor de p al padre de p
                  }
                  else//De lo contrario
                  {
                      if(s->der->color=='b')//Si el hijo der de s es negro
                      {
                             s->izq->color=='b';//Se establece el color del hijo izq a negro
                             s->color='r';//Se establece el color de s a rojo
                             rightrotate(s);//Se rota a la der en base a s
                             s=p->padre->der;//Se establece el valor de s al valor del hijo der del padre de p
                      }
                      s->color=p->padre->color;//Se establece el color de s al color del padre de p
                      p->padre->color='b';//Se establece el color del padre de p a negro
                      s->der->color='b';//Se establece el color del hijo derecho de s a negro
                      leftrotate(p->padre);//Se rota a la izq en base al padre de p
                      p=raiz;//Se establece a p conforme al valor de la raiz
                  }
          }
          else//De lo contario
          {
                  s=p->padre->izq;//Se establece el valor de s al del hijo del padre de p
                  if(s->color=='r')//Si el color de s es rojo
                  {
                        s->color='b';//Se establece el color de s a negro
                        p->padre->color='r';//Se establece el color del padre de p a rojo
                        rightrotate(p->padre);//Se rota a la der en base al padre de p
                        s=p->padre->izq;//Se establece a s al valor del hijo izq del padre de p
                  }
                  if(s->izq->color=='b'&&s->der->color=='b')//Si el el color del hijo izq de s es negro y el color del hijo der de s es negro
                  {
                        s->color='r';//Se establece el color de s a rojo
                        p=p->padre;//Se establece el valor de p al padre de p
                  }
                  else//De lo contrario
                  {
                        if(s->izq->color=='b')//Si el hijo izq de s es negro
                        {
                              s->der->color='b';//Se establece el hijo der de s a negro
                              s->color='r';//Se establece el color de s a rojo
                              leftrotate(s);//Se rota a la izq en base a s
                              s=p->padre->izq;//Se establece el valor de s al del hijo izq del padre de p
                        }
                        s->color=p->padre->color;//Se establece el color de s  igual al color del padre de p
                        p->padre->color='b';//Se establece el color del padre de p a negro
                        s->izq->color='b';//Se establece el hijo izq de s a negro
                        rightrotate(p->padre);//Se rota a la der en base al padre de p
                        p=raiz;//Se establece el valor de p a la raiz
                  }
          }
       p->color='b';//Se establece el color de p a negro
       raiz->color='b';//Se establece el color de la raiz a negro
    }
}

void RBtree::leftrotate(nodo *p)//Esta funcion realiza la rotacion izq en base a un nodo dado
{
     if(p->der==NULL)//Si el valor del hijo der de p es igual a null
           return ;//Se hace return
     else//De lo contrario
     {
           nodo *y=p->der;//Se establece un apuntador y con el valor del hijo der de p
           if(y->izq!=NULL)//Si el hijo izq de y es diferente de null
           {
                  p->der=y->izq;//Se establece el hijo der de p al valor del hijo izq de y
                  y->izq->padre=p;//Se establece el padre del hijo izq de y al valor de p
           }
           else//De lo contrario
                  p->der=NULL;//Se establece el valor del hijo der de p a null
           if(p->padre!=NULL)//Si el padre de p es diferente de null
                y->padre=p->padre;//Se establece el valor del padre de y a el valor del padre de p
           if(p->padre==NULL)//Si el padre de p es igual a null
                raiz=y;//Se establece el valor de la raiz al de y
           else//De lo contrario
           {
               if(p==p->padre->izq)//Si p es igual al hijo izq del padre de p
                       p->padre->izq=y;//Se establece el hijo izq del padre de p al valor de y
               else//De lo contrario
                       p->padre->der=y;//Se establece el hijo der del padre de p al valor de y
           }
           y->izq=p;//Se establece el valor del hijo izq de y al valor de p
           p->padre=y;//Se establecel el valor del padre de p al valor de y
     }
}
void RBtree::rightrotate(nodo *p)//Esta funcion realiza la rotacion derecha en base a un nodo dado
{
     if(p->izq==NULL)//Si el hijo izq de p es igual a null
          return ;//Hace return
     else//De lo contrario
     {
         nodo *y=p->izq;//Se establece un apuntador y con valor del hijo de p
         if(y->der!=NULL)//Si el hijo der de y es diferente de null
         {
                  p->izq=y->der;//Se establece el valor del hijo izq de p al del hijo der de y
                  y->der->padre=p;//Se establece el hijo derecho del padre de y al valor de p
         }
         else//De lo contrario
                 p->izq=NULL;//Se establece el hijo izq de p a null
         if(p->padre!=NULL)//Si el padre de p es diferente de null
                 y->padre=p->padre;//Se establece el padre de y al valor del padre de p
         if(p->padre==NULL)//Si el padre de p es igual a null
               raiz=y;//Se establece el valor de la raiz al de y
         else//De lo contrario
         {
             if(p==p->padre->izq)//Si el hijo de p es igual al hijo izq del padre de p
                   p->padre->izq=y;// Se establece el hijo izq del padre de p al valor de y
             else//De lo contrario
                   p->padre->der=y;// Se establece el hijo der del padre de p a y
         }
         y->der=p;//Se establece el hijo der de y al valor de p
         p->padre=y;//Se establece el padre de p al valor de y
     }
}

nodo* RBtree::successor(nodo *p)
{
      nodo *y=NULL;//Se establece un apuntador y con valor NULL
     if(p->izq!=NULL)//Si el hijo izq de p es diferente de null
     {
         y=p->izq;//Se establece y al valor del hijo izq de p
         while(y->der!=NULL)//Mientras el hijo der de y sea diferente de null se repetira este bloque de codigo
              y=y->der;//Se establece y al valor del hijo der de y
     }
     else//De lo contrario
     {
         y=p->der;//Se establece y al valor del hijo der de p 
         while(y->izq!=NULL)//Mientras el hijo izq de p sea diferente de null se repetira este bloque de codigo
              y=y->izq;//Se establece y al valor del hijo izq de y
     }
     return y;//Se retorna con el valor de y
}

void RBtree::disp()//Esta funcion imprime la el arbol
{
     display(raiz);//Se llama a la impresion con el valor inicial raiz
}
void RBtree::display(nodo *p)//Esta funcion realiza la impresion de los datos del nodo dado
{
     if(raiz==NULL)//Si la raiz es igual a null
     {
          printf("\nEmpty Tree.");
          return ;//Se hace return
     }
     if(p!=NULL)//Si el apuntador p es diferente de NULL
     {
                printf("\n\t Nodo: ");
                printf("\n Llave: %d",p->llave);//Se imprime la llave
                printf("\n Color: ");
    if(p->color=='b')//Si el color de p es igual a negro se
     printf("Negro");
    else//De lo contrario
     printf("Rojo");
                if(p->padre!=NULL)//Si el padre de p es diferente de null
                       printf("\n Padre: %d",p->padre->llave);
                else//De lo contrario
                       printf("\n No hay padre del nodo");
                if(p->der!=NULL)//Si el hijo der de p es diferente de null
                       printf("\nHijo derecho: %d",p->der->llave);
                else//De lo contrario
                       printf("\n TNo hay hijo derecho del nodo");
                if(p->izq!=NULL)//Si el hijo izq de p s diferente de null
                       printf("\n Hijo izquierdo: %d",p->izq->llave);
                else//De lo contrario
                       printf("\n TNo hay hijo izquierdo del nodo");
                printf("\n");
    if(p->izq)//Si el hijo izq de p existe
    {
                 printf("\n\nIzquierda:\n");
     display(p->izq);//Se llama a imprimir los datos del hijo izq de p
    }
    else
     printf("\nNo hay hijo izquierdo.\n");
    if(p->der)//Si el hijo der de p existe
    {
     printf("\n\nDerecha:\n");
                 display(p->der);//Se llama a imprimir los datos del hijo der de p
    }
    else//De lo contrario
     printf("\nNo hay hijo derecho.\n");
     }
}
void RBtree::search()//Esta funcion realiza la busqueda del nodo ingresado
{
     if(raiz==NULL)//Si la raiz es igual a null
     {
           printf("\nArbol vacio\n");
           return  ;//Se hace return
     }
     int x;//Se definen variables auxiliares
     printf("\n Ingrese el valor de la llave a buscar: ");
     scanf("%d",&x);//Se captura el valor de x
     fflush(stdin);//Limpieza de buffer
     nodo *p=raiz;//Se establece un apuntador p con valor de la raiz
     int found=0;//Se establece una variable auxiliar para el valor a buscar
     while(p!=NULL&& found==0)//Mientras el valor de p sea diferente de null y el valor de found sea == 0 se ejecutara este fragmento de codigo 
     {
            if(p->llave==x)//Si la llave de p es igual a x
                found=1;//Se cambia el valor de found a 1
            if(found==0)//Si found es igual a 0 
            {
                 if(p->llave<x)//Si la llave de p es menor a x
                      p=p->der;//Se establece p con el valor del hijo der de p
                 else
                      p=p->izq;//Se establece p con el valor del hijo izq de p
            }
     }
     if(found==0)//Si found es igual a 0
          printf("\nElemento no encontrado.");
     else//De lo contrario
     {
                printf("\n\t Nodo Encontrado: ");
                printf("\n Llave: %d",p->llave);
                printf("\n Color: ");
    if(p->color=='b')//Si el color de p es igual a negro
     printf("Negro");
    else//De lo contrario
     printf("Rojo");
                if(p->padre!=NULL)//Si el valor del padre de p es diferente de NULL
                       printf("\n Padre: %d",p->padre->llave);
                else//De lo contrario
                       printf("\n No hay padre del nodo");
                if(p->der!=NULL)//Si el valor del hijo der de p es diferente de null
                       printf("\nHijo derecho: %d",p->der->llave);
                else//De lo contrario
                       printf("\n TNo hay hijo derecho del nodo");
                if(p->izq!=NULL)//Si el valor del hijo izq de p es diferente de null
                       printf("\n Hijo izquierdo: %d",p->izq->llave);
                else//De lo contrario
                       printf("\n TNo hay hijo izquierdo del nodo");
                printf("\n");

     }
}
int main()
{
    int opc,y=0;//Se definen variables de control
    RBtree RBT;//Se crea la clase de RBtree con nombre RBT
    do{//Se repetira este fragmento de codigo
		printf("Arbol RB");
        printf("\n 1. Insertar en arbol ");
        printf("\n 2. Eliminar nodo de arbol");
        printf("\n 3. Buscar elemento en arbol");
        printf("\n 4. Imprimir arbol ");
        printf("\n 5. Salir" );
        printf("\nSelecciona una opcion ");
        scanf("%d",&opc);//Se captura el valor de opc
        fflush(stdin);//Limpieza de buffer
        switch(opc){//Este switch alternara el valor y entrara al case correspondiente
            case 1 : RBT.insert();//Se llama a la funcion insert para cambios en RBT
                printf("\nNodo Insertado.\n");
                break;
            case 2 : RBT.del();//Se llama a la funcion DELETE para cambios en RBT
                break;
            case 3 : RBT.search();//Se llama a la funcion SEARCH para cambios en RBT
            	break;
            case 4 : RBT.disp();//Se llama a la funcion IMPRESION para RBT
                break;
            case 5 : y=1;//Se establece a y con valor de 1
                break;
            default : printf("\nOpcion invalida");//Default para cualquier entrada no incluida
                }
            printf("\n");//Espaciador

    	
        }while(y!=1);//Minetras y sea diferente de 1 se repetira este do
    return 1;
}
