#include<stdio.h>//Funciones de entrada y salida estandar
#include<conio.h>
#include <windows.h>//Para usar cls 

void counting_sort(int arraysort[],int n,int max);//Definicion de funciones prototipo
 
int main(){	
 			printf("-------173389, Mendoza Monreal Jose Israel,Counting-Sort Analisis Algoritmos , 01-07-2021, Verano 2021--------\n");//Datos de Alumno
	for(int i=0;i<102;i++){
		printf("_");
	}//Separador
	printf("\n");//Espaciador
	
	int n;//Variable para tama�o
	int i,max=0;//Variable para for y maximos
	printf("Ingrese el numero de elementos: ");
	scanf("%d",&n);//Guarda la entrada de tama�o
	fflush(stdin);//Limpieza de buffer
	int arraysort[50];//Define el tama�o de el array en este caso un determinado de 50 valores
	for(int i = 0; i < n; i++){//Este ciclo for pide y almacena los n valores que se ingresen
		printf("Ingrese el elemento %d\n",(i+1));
		scanf("%d",&arraysort[i]);//Guarda el valor dentro del espacio del arraysort
	    fflush(stdin);//Limpieza de buffer
	     if(arraysort[i]>max)//Este if determina si la entrada realizada es mayor al maximo actual
	      max=arraysort[i];//Se establece el nuevo maximo si se cumple el if
	    
	    	 	
	}
    counting_sort(arraysort,n,max);//Llamada de funcion de counting sort
	getch();//Espera el apretado de una tecla para seguir    
    return 0;
}

void counting_sort(int arraysort[],int n,int max){//Esta funcion realiza el counting-sort, determinando la cantidad de valores mayores que existen por cierto variable y estableciendo un orden predispuesto en base este
     int contador[50]={0},i,j;//Se establecen las variables de los contadores for y se establece el array secundario de 50 posibles valores 0-49
    
     for(i=0;i<n;++i)//Este for determina la cantidad de veces que se repite un valor y lo almacena en el array secundario
      contador[arraysort[i]]=contador[arraysort[i]]+1;
      
     printf("\nSorted elements are:");
    
     for(i=0;i<=max;i++){//Este for anidado imprimira toda la matriz ordenada hasta que se llegue al valor maximo
      for(j=1;j<=contador[i];++j){//Este for anidado inferior realiza la impresion del valor de cantidad de repeticiones y termina cuando dichos valores llegan a 0 para el posible valor
      	printf("%d - ",i);	
	  }
     }
}
